import "./styles.css";
export default function two(){
function  on(){

  document.getElementById('img').src="https://www.google.com/imgres?imgurl=https%3A%2F%2Fpreviews.123rf.com%2Fimages%2Fssilver%2Fssilver1509%2Fssilver150900029%2F45206414-vintage-light-blub.jpg&tbnid=X2MgblcEgDapPM&vet=12ahUKEwifqpOKlayAAxVammMGHd2vBnwQMygEegUIARD0AQ..i&imgrefurl=https%3A%2F%2Fwww.123rf.com%2Fphoto_45206414_vintage-light-blub.html&docid=TTs1pFEcjI6kDM&w=1300&h=866&q=blub%20image%20on%20image&ved=2ahUKEwifqpOKlayAAxVammMGHd2vBnwQMygEegUIARD0AQ"
}

function off(){
  document.getElementById('img').src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.freepik.com%2Ffree-photos-vectors%2Fblub&psig=AOvVaw2_F1Zr0ckOVLq6CRxU9YTK&ust=1690452661482000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCJCJrYuRrIADFQAAAAAdAAAAABAD"
}