import "./styles.css";
export default function Sub() {
  const Sub1 = (props) => {
    let res = <h1>The sub is{props.name.num1 - props.name.num2}</h1>;
    return res;
  };
  const Add = (props) => {
    let res = <h1>The Add is{props.name.num1 - props.name.num2}</h1>;
    return res;
  };
  const Sum = () => {
    const obj1 = { num1: 5, num2: 7 };
    return (
      <>
        <div>
          <h1>SUBTRACTION</h1>
          <Sub1 name={obj1} />
        </div>
      </>
    );
  };
  return (
    <>
      <div>
        <h2>HI</h2>
        <Sum />
      </div>
    </>
  );
}