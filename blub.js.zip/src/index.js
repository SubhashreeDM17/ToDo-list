import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import ToDo-list  "./ToDo List";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <StrictMode>
    <ToDo-list/>
  </StrictMode>
);
